void Hex2Str( char *sSrc,  char *sDest, int nSrcLen );
void Str2Hex( char *sSrc, char *sDest, int nSrcLen);
